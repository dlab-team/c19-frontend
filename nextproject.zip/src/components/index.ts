export { IAMessage } from "./ia/IAMessage";
export { ContainerCodeRender } from "./courses/ContainerCodeRender";
export { Advance } from "./common/Advance";
export { Discord } from "./common/Discord";
export { CommentCard } from "./home/CommentCard";
export { Comments } from "./home/Comments";
export { Footer } from "./common/Footer";
export { Header } from "./common/Header";
export { Enunciado } from "./courses/Enunciado";

export { CodeEditor } from "./courses/CodeEditor";
export { Render } from "./courses/Render-Exercise";
